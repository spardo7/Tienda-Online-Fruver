    const express = require('express');
const router  = express.Router();

const {
  crearPaquete,
  obtenerPaquetes,
  obtenerPaquetePorId,
  actualizarEstadoPaquete
} = require('../controllers/paquetes.controller');

router.post('/',    crearPaquete);
router.get('/',     obtenerPaquetes);
router.get('/:id',  obtenerPaquetePorId);
router.put('/:id',  actualizarEstadoPaquete);

module.exports = router;