const mongoose = require('mongoose');

const repartidorSchema = new mongoose.Schema({
  nombre: {
    type: String,
    required: true
  },
  identificacion: {
    type: String,
    required: true,
    unique: true
  },
  ubicacionActual: {
    type: {
      type: String,
      enum: ['Point'],
      default: 'Point'
    },
    coordinates: {
      type: [Number],
      default: [-74.1448, 4.6403]
    }
  }
}, { timestamps: true });

repartidorSchema.index({ ubicacionActual: '2dsphere' });

module.exports = mongoose.model('Repartidor', repartidorSchema);