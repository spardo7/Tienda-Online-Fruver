const mongoose = require('mongoose');

const paqueteSchema = new mongoose.Schema({
  numeroGuia: {
    type: String,
    required: true,
    unique: true
  },
  remitente: {
    nombre:    { type: String },
    direccion: { type: String },
    telefono:  { type: String }
  },
  destinatario: {
    nombre:    { type: String },
    direccion: { type: String },
    telefono:  { type: String }
  },
  dimensiones: {
    alto:  { type: Number },
    ancho: { type: Number },
    largo: { type: Number },
    peso:  { type: Number }
  },
  estado: {
    type: String,
    enum: ['En bodega', 'En ruta', 'Entregado', 'Incidencia'],
    default: 'En bodega'
  },
  repartidorAsignado: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Repartidor',
    default: null
  },
  historialUbicaciones: [
    {
      lat:   { type: Number },
      lon:   { type: Number },
      fecha: { type: Date, default: Date.now }
    }
  ]
}, { timestamps: true });

module.exports = mongoose.model('Paquete', paqueteSchema);