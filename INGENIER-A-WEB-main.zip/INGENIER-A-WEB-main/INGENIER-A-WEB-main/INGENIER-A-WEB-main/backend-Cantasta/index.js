const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

const paqueteSchema = new mongoose.Schema({
  numeroGuia: { type: String, required: true, unique: true },
  remitente: { nombre: String, direccion: String, telefono: String },
  destinatario: { nombre: String, direccion: String, telefono: String },
  dimensiones: { alto: Number, ancho: Number, largo: Number, peso: Number },
  estado: { type: String, enum: ['En bodega','En ruta','Entregado','Incidencia'], default: 'En bodega' },
  repartidorAsignado: { type: mongoose.Schema.Types.ObjectId, ref: 'Repartidor', default: null },
  historialUbicaciones: [{ lat: Number, lon: Number, fecha: { type: Date, default: Date.now } }]
}, { timestamps: true });

const repartidorSchema = new mongoose.Schema({
  nombre: { type: String, required: true },
  identificacion: { type: String, required: true, unique: true },
  ubicacionActual: {
    type: { type: String, enum: ['Point'], default: 'Point' },
    coordinates: { type: [Number], default: [-74.1448, 4.6403] }
  }
}, { timestamps: true });

const Paquete    = mongoose.model('Paquete', paqueteSchema);
const Repartidor = mongoose.model('Repartidor', repartidorSchema);

app.post('/api/paquetes', async (req, res) => {
  try {
    const p = new Paquete(req.body);
    const guardado = await p.save();
    res.status(201).json(guardado);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/paquetes', async (req, res) => {
  try {
    const paquetes = await Paquete.find();
    res.status(200).json(paquetes);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/paquetes/:id', async (req, res) => {
  try {
    let p = await Paquete.findOne({ numeroGuia: req.params.id });
    if (!p) p = await Paquete.findById(req.params.id);
    if (!p) return res.status(404).json({ error: 'Paquete no encontrado' });
    res.status(200).json(p);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.put('/api/paquetes/:id', async (req, res) => {
  try {
    const p = await Paquete.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!p) return res.status(404).json({ error: 'Paquete no encontrado' });
    res.status(200).json(p);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/repartidores', async (req, res) => {
  try {
    const r = new Repartidor(req.body);
    const guardado = await r.save();
    res.status(201).json(guardado);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/repartidores', async (req, res) => {
  try {
    const repartidores = await Repartidor.find();
    res.status(200).json(repartidores);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/repartidores/ubicaciones', async (req, res) => {
  try {
    const repartidores = await Repartidor.find({}, 'nombre ubicacionActual');
    res.status(200).json(repartidores);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/', (req, res) => {
  res.json({ mensaje: 'API La Canasta Familiar funcionando' });
});

mongoose.connect(process.env.MONGO_URI)
  .then(() => {
    console.log('Conectado a MongoDB Atlas');
    app.listen(process.env.PORT || 5000, () => {
      console.log('Servidor corriendo en http://localhost:5000');
    });
  })
  .catch(err => console.error('Error:', err.message));