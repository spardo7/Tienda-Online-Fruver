const Paquete = require('../models/paquete.model');

// POST /api/paquetes — Crear un nuevo paquete
const crearPaquete = async (req, res) => {
  try {
    const paquete = new Paquete(req.body);
    const guardado = await paquete.save();
    res.status(201).json(guardado);
  } catch (error) {
    if (error.code === 11000) {
      return res.status(400).json({ error: 'El número de guía ya existe.' });
    }
    res.status(500).json({ error: error.message });
  }
};

// GET /api/paquetes — Obtener todos los paquetes
const obtenerPaquetes = async (req, res) => {
  try {
    const paquetes = await Paquete.find().populate('repartidorAsignado', 'nombre identificacion');
    res.status(200).json(paquetes);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// GET /api/paquetes/:id — Obtener un paquete por numeroGuia o _id
const obtenerPaquetePorId = async (req, res) => {
  try {
    const { id } = req.params;

    // Busca primero por numeroGuia, si no por _id
    let paquete = await Paquete.findOne({ numeroGuia: id }).populate('repartidorAsignado', 'nombre identificacion');
    if (!paquete) {
      paquete = await Paquete.findById(id).populate('repartidorAsignado', 'nombre identificacion');
    }

    if (!paquete) {
      return res.status(404).json({ error: 'Paquete no encontrado.' });
    }

    res.status(200).json(paquete);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// PUT /api/paquetes/:id — Actualizar estado de un paquete
const actualizarEstadoPaquete = async (req, res) => {
  try {
    const { id } = req.params;
    const { estado, historialUbicaciones } = req.body;

    const estadosValidos = ['En bodega', 'En ruta', 'Entregado', 'Incidencia'];
    if (estado && !estadosValidos.includes(estado)) {
      return res.status(400).json({ error: `Estado inválido. Usa: ${estadosValidos.join(', ')}` });
    }

    const actualizar = {};
    if (estado) actualizar.estado = estado;
    if (historialUbicaciones) actualizar.$push = { historialUbicaciones };

    const paquete = await Paquete.findByIdAndUpdate(id, actualizar, { new: true });

    if (!paquete) {
      return res.status(404).json({ error: 'Paquete no encontrado.' });
    }

    res.status(200).json(paquete);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

module.exports = {
  crearPaquete,
  obtenerPaquetes,
  obtenerPaquetePorId,
  actualizarEstadoPaquete
};